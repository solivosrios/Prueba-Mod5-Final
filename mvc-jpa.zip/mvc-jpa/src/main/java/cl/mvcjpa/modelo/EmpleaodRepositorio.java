package cl.mvcjpa.modelo;

import org.springframework.data.repository.CrudRepository;

public interface EmpleaodRepositorio extends CrudRepository<Empleado, Integer>{

}
